package com.example.topic6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
