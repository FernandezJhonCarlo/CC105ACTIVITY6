class Idol {
  final String name;
  final String idol;
  final int love;

  Idol({this.name, this.idol, this.love});
}
